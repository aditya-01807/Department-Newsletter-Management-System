# Department Newsletter Management & Analytics System

## Setup
1. Extract ZIP and open the folder in VS Code.
2. Run `python -m venv venv`
3. Activate it in PowerShell: `.env\Scripts\Activate.ps1`
4. Install: `pip install -r requirements.txt`
5. Copy `.env.example` to `.env`.
6. Put your existing Atlas connection string in `MONGO_URI`; do not share it.
7. Change `SECRET_KEY`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD`.
8. Run `python app.py`, then open http://127.0.0.1:5000/

Features: Admin/Faculty/Student roles; hashed passwords; article review; event and achievement submissions; search; CSV download; category/status charts; user-role management. Existing DepartmentNewsletter.articles data is preserved.
