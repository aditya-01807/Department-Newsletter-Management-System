import os, io, csv
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, make_response, abort
from pymongo import MongoClient, DESCENDING
from bson.objectid import ObjectId
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret")
uri = os.getenv("MONGO_URI", "")
if not uri:
    raise RuntimeError("Set MONGO_URI in your .env file. Never put database credentials in app.py.")
client = MongoClient(uri, serverSelectionTimeoutMS=8000)
client.admin.command("ping")
db = client["DepartmentNewsletter"]
articles, events, achievements, users = db.articles, db.events, db.achievements, db.users
print("MongoDB Connected Successfully!")

email, password = os.getenv("ADMIN_EMAIL", "").lower().strip(), os.getenv("ADMIN_PASSWORD", "")
if email and password and not users.find_one({"email": email}):
    users.insert_one({"name": os.getenv("ADMIN_NAME", "Department Admin"), "email": email,
                      "password_hash": generate_password_hash(password), "role": "Admin",
                      "created_at": datetime.utcnow()})
    print("Admin account created from .env")

def me():
    return users.find_one({"_id": ObjectId(session["uid"])}) if session.get("uid") else None

@app.context_processor
def common():
    return {"current_user": me(), "year": datetime.now().year}

def require(*roles):
    def deco(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            user = me()
            if not user:
                flash("Please log in first.", "warning")
                return redirect(url_for("login"))
            if roles and user.get("role") not in roles:
                abort(403)
            return fn(*args, **kwargs)
        return wrapped
    return deco

def oid(value):
    try: return ObjectId(value)
    except Exception: abort(404)

@app.route("/")
def home():
    return render_template("index.html",
        articles=list(articles.find({"status":"Approved"}).sort("_id", DESCENDING).limit(12)),
        events=list(events.find({"status":"Approved"}).sort("_id", DESCENDING).limit(6)),
        achievements=list(achievements.find({"status":"Approved"}).sort("_id", DESCENDING).limit(6)))

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        name=request.form.get("name","").strip(); email=request.form.get("email","").strip().lower()
        pw=request.form.get("password",""); role=request.form.get("role","Student")
        if not name or not email or len(pw)<8 or role not in ("Student","Faculty"):
            flash("Complete all fields. Password must be at least 8 characters.", "danger")
        elif users.find_one({"email":email}):
            flash("That email is already registered.", "danger")
        else:
            users.insert_one({"name":name,"email":email,"password_hash":generate_password_hash(pw),
                              "role":role,"created_at":datetime.utcnow()})
            flash("Account created. Please log in.", "success"); return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        user=users.find_one({"email":request.form.get("email","").strip().lower()})
        if user and check_password_hash(user.get("password_hash",""),request.form.get("password","")):
            session.clear(); session["uid"]=str(user["_id"])
            return redirect(url_for("admin" if user["role"]=="Admin" else "dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("home"))

@app.route("/dashboard")
@require("Faculty","Student")
def dashboard():
    u=me()
    return render_template("dashboard.html", user=u,
        mine=list(articles.find({"author_email":u["email"]}).sort("_id",-1)),
        myach=list(achievements.find({"submitted_by":u["email"]}).sort("_id",-1)))

@app.route("/submit", methods=["GET","POST"])
@require("Faculty","Student")
def submit():
    if request.method=="POST":
        u=me(); title=request.form.get("title","").strip()
        category=request.form.get("category","").strip(); content=request.form.get("content","").strip()
        if title and category and content:
            articles.insert_one({"title":title,"author":u["name"],"author_email":u["email"],
                "category":category,"content":content,"status":"Pending","created_at":datetime.utcnow()})
            flash("Article submitted for admin review.", "success"); return redirect(url_for("dashboard"))
        flash("Please fill in every field.", "danger")
    return render_template("submit.html")

@app.route("/events/add", methods=["GET","POST"])
@require("Faculty","Admin")
def add_event():
    if request.method=="POST":
        title=request.form.get("title","").strip(); date=request.form.get("date","").strip()
        desc=request.form.get("description","").strip()
        if title and date and desc:
            events.insert_one({"title":title,"event_date":date,"description":desc,
                "submitted_by":me()["email"],"status":"Pending","created_at":datetime.utcnow()})
            flash("Event submitted for review.", "success")
            return redirect(url_for("admin" if me()["role"]=="Admin" else "dashboard"))
        flash("Please fill in every field.", "danger")
    return render_template("event_form.html")

@app.route("/achievements/add", methods=["GET","POST"])
@require("Faculty","Student","Admin")
def add_achievement():
    if request.method=="POST":
        title=request.form.get("title","").strip(); person=request.form.get("person","").strip()
        desc=request.form.get("description","").strip(); u=me()
        if title and person and desc:
            achievements.insert_one({"title":title,"person":person,"description":desc,
                "submitted_by":u["email"],"status":"Pending","created_at":datetime.utcnow()})
            flash("Achievement submitted for review.", "success")
            return redirect(url_for("admin" if u["role"]=="Admin" else "dashboard"))
        flash("Please fill in every field.", "danger")
    return render_template("achievement_form.html")

@app.route("/search")
def search():
    q=request.args.get("q","").strip(); found=[]
    if q:
        found=list(articles.find({"status":"Approved","$or":[
            {"title":{"$regex":q,"$options":"i"}},{"content":{"$regex":q,"$options":"i"}},
            {"category":{"$regex":q,"$options":"i"}}]}).sort("_id",-1).limit(50))
    return render_template("search.html", q=q, results=found)

@app.route("/download.csv")
def download():
    out=io.StringIO(); w=csv.writer(out); w.writerow(["Title","Author","Category","Content"])
    for a in articles.find({"status":"Approved"}).sort("_id",-1):
        w.writerow([a.get("title",""),a.get("author",""),a.get("category",""),a.get("content","")])
    r=make_response(out.getvalue()); r.headers["Content-Disposition"]="attachment; filename=department_newsletter.csv"
    r.headers["Content-Type"]="text/csv; charset=utf-8"; return r

@app.route("/admin")
@require("Admin")
def admin():
    stats={"total":articles.count_documents({}),"approved":articles.count_documents({"status":"Approved"}),
      "pending":articles.count_documents({"status":"Pending"}),"rejected":articles.count_documents({"status":"Rejected"}),
      "events":events.count_documents({}),"achievements":achievements.count_documents({})}
    stats["contributors"]=len(set(articles.distinct("author_email")+achievements.distinct("submitted_by")))-1
    cats=list(articles.aggregate([{"$match":{"status":"Approved"}},{"$group":{"_id":"$category","count":{"$sum":1}}},{"$sort":{"count":-1}}]))
    return render_template("admin.html",stats=stats,cats=cats,
      all_articles=list(articles.find().sort("_id",-1)),
      all_events=list(events.find().sort("_id",-1)),
      all_ach=list(achievements.find().sort("_id",-1)),
      all_users=list(users.find({},{"password_hash":0}).sort("_id",-1)))

@app.route("/admin/action/<kind>/<item>/<action>", methods=["POST"])
@require("Admin")
def action(kind,item,action):
    col={"article":articles,"event":events,"achievement":achievements}.get(kind)
    if col is None or action not in ("approve","reject","delete"): abort(404)
    if action=="delete": col.delete_one({"_id":oid(item)})
    else: col.update_one({"_id":oid(item)},{"$set":{"status":"Approved" if action=="approve" else "Rejected"}})
    flash(f"{kind.title()} {action}d.", "success"); return redirect(url_for("admin"))

@app.route("/admin/users/<user_id>", methods=["POST"])
@require("Admin")
def user_role(user_id):
    role=request.form.get("role")
    target=users.find_one({"_id":oid(user_id)})
    if role not in ("Admin","Faculty","Student") or not target: abort(400)
    if target["_id"]==me()["_id"]: flash("You cannot change your own role.", "warning")
    else: users.update_one({"_id":target["_id"]},{"$set":{"role":role}}); flash("User role updated.", "success")
    return redirect(url_for("admin"))

@app.errorhandler(403)
def forbidden(e): return render_template("error.html",code=403,message="Your account cannot access this page."),403
@app.errorhandler(404)
def missing(e): return render_template("error.html",code=404,message="Page or item not found."),404

if __name__=="__main__": app.run(debug=False)
